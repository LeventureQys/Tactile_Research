# 五类传感器 · v3.4 观测器批量复算与调参（2026-09-26）

数据：`D:\workshop\文档\v2.7 - 抗蠕变补偿算法\data`（四指指腹 4 会话、右拇指指腹 2、
左拇指指腹 2、右手掌 4、左手掌 4，共 16 份；52/57/71 通道，29~277 s，约 100.5 Hz，ADC 模式、
录制时算法关闭 ⇒ 该 CSV 即算法输入）。

算法：**C++ 现役 v3.4 观测器本体**（`src/domain/drift_v6/creep_observer.cpp`，27 参数 /
每通道 11 状态），离线复算器 `v34_sweep.cpp` 直接编译链接该源文件，与上位机逐帧同口径。

---

## 一、本轮（第二轮）改了什么

第一轮按「比例制」目标选参（末值残漂 / 末 30 s 漂移 / 过扣比例），结果在实机曲线上出现两个问题：
**拇指指腹 x1 阶段有明显过减、右手掌基线漂移太大**。本轮把口径改成**绝对 ADC**并加了硬约束：

- 参考线：有加载台阶的会话取拟合弹性电平 ΣE；无台阶的会话取 0（调零后的起始基线）。
- **过减 low_exc** = 显示被压到参考线**下方**多少 ADC（字面意义的"过减"，你的验收项 50~150）；
- 回落 notch = 显示（0.2 s 中值滤波）相对历史最高点的最大回落；
- 欠减峰 peak_exc / 末值偏差 end_exc = 显示浮在参考线上方多少 / 末值偏差（= 基线漂移）。
- 目标函数 `J = peak_exc + 0.5·|end_exc| + 4·max(0, low_exc − 100) + max(0, notch − 150)`，
  即**先把过减压到容差内**，再让显示尽量贴着参考线。

**找到的关键机理**：`slope_cap_frac`（慢态积分速率上限）是「显示能压多低」的硬约束——
`cap = slope_cap_frac·max(e,1)` 必须 ≥ 输入爬升率，否则显示被迫抬到 ≥ 爬升率/`slope_cap_frac`
才追得上，慢态就永远欠扣。这类"无弹性台阶、读数一路爬"的传感器需要
**`slope_cap_frac` 3~6**（现役 0.01、UI 上限 0.05）。同时把沿阈放到极大（3000/1e9）等于
**关掉"加载沿"机制**——这几类传感器本来就没有台阶，沿机制只会反复阻挡慢态积分。

## 二、本轮定稿结果（逐会话平均，单位 ADC）

| 传感器 | 回落 notch 均/最大 | 过减 low_exc | 欠减峰 peak_exc | 末值偏差 | 蠕变扣除率 | 上一轮 过减/扣除 |
|---|---|---|---|---|---|---|
| 四指指腹 | 110 / 236 | 100 | 83 | +1 | **106 %** | 64 / 89 % |
| 右拇指指腹 | 136 / 150 | 98 | 95 | +32 | **110 %** | 0 / 73 % |
| 左拇指指腹 | 169 / 192 | 50 | 127 | +54 | **104 %** | 0 / 59 % |
| 右手掌 | 136 / 175 | 60 | 89 | +43 | **102 %** | 0 / 71 % |
| 左手掌 | 82 / 103 | 84 | 11 | -21 | **112 %** | 0 / 70 % |

（"上一轮 过减/扣除" = 第一轮比例制预设的 过减 low_exc 与扣除率，用于对比。）

### 回落归因（本轮定稿预设，逐会话分解）

| 项 | 平均 | 说明 |
|---|---|---|
| 输入自身的回落 | 88 ADC | 手指/夹具压力本身在波动，工况固有，任何算法都改不了 |
| 显示回落 | 123 ADC | 曲线看上去的"下拉" |
| **算法额外造成的回落** | **35 ADC**（最大 115） | 这才是算法该负责的部分，已压到你给的 50~150 量级内 |

逐会话明细见 `03_结果/19_notch_attr.json`、`03_结果/15_compare.json`。


## 三、推荐预设

### 四指指腹

```json
{"r_fast": 0.01, "tau_c_fast_s": 4.0, "r_slow_max": 0.1, "slope_cap_frac": 1.5, "slope_gate_frac": 2.0, "slow_confirm_s": 0.5, "soft_unfreeze_s": 4.0, "edge_slope_thres": 400.0, "tau_slope_s": 0.2, "tau_r_slow_idle_s": 0.0, "tau_r_fast_s": 2.0, "hold_eps": 0.0, "idle_frac": 0.02, "ramp_slope_min": 2.0, "edge_boost_s": 0.0, "tau_c_fast_boost_s": 4.0, "hold_tau_s": 0.15, "ramp_full_s": 0.0}
```

本轮定稿（来源：四指指腹专项）。过减(显示沉到参考线下) 100 ADC、欠减峰 83 ADC、扣除率 106%；现役默认为 过减 957 / 欠减峰 0 / 扣除 210%。

### 右拇指指腹

```json
{"r_fast": 2.0, "tau_c_fast_s": 1.0, "r_slow_max": 30.0, "slope_cap_frac": 10.0, "slope_gate_frac": 5.0, "slow_confirm_s": 0.5, "soft_unfreeze_s": 0.2, "edge_slope_thres": 3000.0, "edge_boost_s": 0.0, "tau_slope_s": 0.5, "tau_r_slow_idle_s": 0.0, "tau_r_fast_s": 1.0, "hold_eps": 0.5, "hold_tau_s": 0.2, "idle_frac": 0.1, "ramp_slope_min": 0.0, "ramp_full_s": 0.0}
```

本轮定稿（来源：细网格收敛）。过减(显示沉到参考线下) 98 ADC、欠减峰 95 ADC、扣除率 110%；现役默认为 过减 0 / 欠减峰 1601 / 扣除 11%。

### 左拇指指腹

```json
{"r_fast": 2.0, "tau_c_fast_s": 1.0, "tau_c_fast_boost_s": 4.0, "r_slow_max": 100.0, "slope_cap_frac": 0.8, "slope_gate_frac": 2.0, "slow_confirm_s": 0.0, "soft_unfreeze_s": 0.05, "edge_slope_thres": 3000.0, "edge_boost_s": 0.0, "tau_slope_s": 0.2, "tau_r_slow_idle_s": 2.0, "tau_r_fast_s": 0.2, "hold_eps": 0.0, "hold_tau_s": 0.2, "idle_frac": 0.02, "ramp_slope_min": 0.5, "ramp_full_s": 4.0}
```

本轮定稿（来源：细网格收敛）。过减(显示沉到参考线下) 50 ADC、欠减峰 127 ADC、扣除率 104%；现役默认为 过减 0 / 欠减峰 1764 / 扣除 18%。

### 右手掌

```json
{"r_fast": 2.0, "tau_c_fast_s": 1.0, "tau_c_fast_boost_s": 0.5, "r_slow_max": 30.0, "slope_cap_frac": 0.4, "slope_gate_frac": 1.0, "slow_confirm_s": 0.0, "soft_unfreeze_s": 0.5, "edge_slope_thres": 1000000000.0, "edge_boost_s": 0.0, "tau_slope_s": 0.5, "tau_r_slow_idle_s": 2.0, "tau_r_fast_s": 1.0, "hold_eps": 0.0, "hold_tau_s": 0.05, "idle_frac": 0.2, "ramp_slope_min": 2.0, "ramp_full_s": 4.0}
```

本轮定稿（来源：细网格收敛）。过减(显示沉到参考线下) 60 ADC、欠减峰 89 ADC、扣除率 102%；现役默认为 过减 0 / 欠减峰 1203 / 扣除 14%。

### 左手掌

```json
{"r_fast": 2.0, "tau_c_fast_s": 1.0, "tau_c_fast_boost_s": 2.0, "r_slow_max": 30.0, "slope_cap_frac": 6.0, "slope_gate_frac": 2.0, "slow_confirm_s": 0.5, "soft_unfreeze_s": 0.05, "edge_slope_thres": 3000.0, "edge_boost_s": 0.0, "tau_slope_s": 0.5, "tau_r_slow_idle_s": 0.5, "tau_r_fast_s": 2.0, "hold_eps": 0.0, "hold_tau_s": 0.1, "idle_frac": 0.1, "ramp_slope_min": 0.5, "ramp_full_s": 4.0}
```

本轮定稿（来源：细网格收敛）。过减(显示沉到参考线下) 84 ADC、欠减峰 11 ADC、扣除率 112%；现役默认为 过减 0 / 欠减峰 745 / 扣除 11%。

## 四、两个必须先知道的口径事实

1. **「不调零就开算法」= 完全不补偿**：手掌/拇指这 12 份录制带着 4915~25120 ADC 的无载偏置，
   读数整体只涨 5~13 %，永远越不过全局总值旁路的 `release = 1.15×baseline`，
   实测 **12/12 会话扣除恒为 0.0 ADC** ⇒ 现场必须「装好负载 → 调零 → 开算法」。
   四指指腹首帧本就是无载零点（0），不受影响。
2. **可扣除比例有硬上限**：`x2 ≤ r_slow_max·max(e,1)` 且 `e = y − x1 − x2`；当弹性电平≈0 时
   `e` ≈ 累计蠕变 ⇒ 上限 = `r_slow_max/(1+r_slow_max)`。默认 0.35 只能扣 25.9 %（实测 6~19 % 吻合），
   扣到 90 % 需要 r≈9，而 UI 上限只有 0.600。

## 五、是否需要新增参数（结论：不需要新增，需要放开可调面）

- **0 个新参数**：预设用到的键全部是 `creep_observer.h::Params` 现有成员
  （脚本 `20_param_gap.py` 直接解析头文件与 kSpecs 核对，见 `03_结果/12_param_gap.json`）。
- **只需"暴露"6 个已有但对话框未暴露的参数**：`slope_gate_frac`、`tau_slope_s`、`idle_frac`、
  `ramp_slope_min`、`hold_eps`、`edge_slope_thres`（本轮还用到 `hold_tau_s`、`tau_c_fast_boost_s`、
  `ramp_full_s`、`edge_boost_s` —— 同属这 19 个未暴露项）。
- **只需"放宽 min/max"**：`r_slow_max` 0.60 → ≥5（拇指/手掌）、**`slope_cap_frac` 0.05 → ≥6**
  （本轮最关键的放宽项）、`r_fast` 0.50 → ≥2。
- 若要求**设备侧也生效**，才需要新增**寄存器**（协议/固件的事，不是算法参数）。

## 六、目录说明

| 目录 | 内容 |
|---|---|
| `01_最终图片/` | **本轮 27 张**：`A_*` 每会话「未补偿输入 / ΣE 参考 / 现役默认 / 第一轮预设 / 本轮推荐」总 ADC 对比（16 张）；`B_*` 每类传感器「残差归一到蠕变」overlay（5 张，含第一轮对照）；`C_*` x1/x2/applied 内部状态轨迹（6 张） |
| `01_最终图片/archived/第1轮（比例制口径）/` | **上一轮同 27 张**，按工作类型分子目录 `A_每会话总ADC对比` / `B_残差归一到蠕变` / `C_内部状态轨迹`，另附 `09_presets_第1轮.json` |
| `02_脚本/` | 分析、寻优、出图、复核脚本（`05_prep`→`06_sweep1d`→`08_search`→`14/24/26/27` 寻优→`28_finalize` 定稿→`09_plot` 出图→`13/17/18/19/20/25` 复核），以及离线复算器源码与编译脚本 |
| `03_结果/` | 各阶段结果与日志（见下） |
| `04_中间数据/` | `参考水位拟合/*.npz`（逐通道弹性电平 E_k 与蠕变分量）；`图源数据.npz`（每会话 `t / 输入_未补偿 / 显示_现役默认 / 显示_第一轮预设 / 显示_本轮推荐 / ΣE / 真实蠕变 / t0`，即 A、B 两组图的数据源） |
| `05_工具/` | `v34_sweep_v3.exe`（离线复算器，输出含 notch/sm_* 绝对口径列）+ 源码 + 编译脚本 |

`03_结果/` 关键文件：`02_prep.json`（ΣE/t0 拟合）、`03_sweep1d.*`（15 旋钮一维扫描）、
`04_search*.json`（比例制三轮寻优）、`05_report.txt`（逐会话明细）、`06_ceiling.json`
（`r/(1+r)` 上限验证）、`07_variant.json`（第 28 个参数否决依据）、`10_nozero.json`（不调零实测）、
`11_ui_gap.json` / `12_param_gap.json`（可调面缺口量化）、`13_trim_before.json`（过减/漂移实测）、
`14_search_adc.json`（绝对口径寻优）、`15_compare.json`（现役/第一轮/本轮三者逐会话对比）、
`16_refine.json`（细网格收敛）、`17_focus.json`（预留池定点收敛）、`09_presets.*`（本轮定稿）。

## 七、如何复跑

```powershell
cd <本包>\02_脚本
python 14_session_bin.py     # 16 份会话 CSV → 二进制（首次必跑）
python 05_prep.py            # 拟合参考弹性电平 ΣE 与加载时刻 t0
python 28_finalize.py        # 从各轮结果里定稿并写 09_presets.json
python 09_plot.py            # 出全部 27 张图（需要 toolbox\数据解析工具 可导入）
```

## 八、口径与环境注意

- 复算时间轴：默认按 `frame_index` 重建**均匀轴**；上位机实际喂算法的是**批量到达时刻**
  （elapsed 约 70 % 重复）。两种口径结论不翻转（各结果里都有 raw 列对照）。
- 输入口径：统一按现场规范「装好负载 → 调零 → 开算法」，即输入 = 原值 − 首帧值。
- 指标分母：比例类指标一律用「本该被扣掉的累计蠕变」；**过减/欠减/回落一律用绝对 ADC**。
- 环境：Python 3.14 / numpy 2.4.6 / scipy 1.17.1 / matplotlib 3.10.9；VS 2022 Community 的 cl.exe
  （`/std:c++17 /O2`），Eigen 取自仓库 `thirdparty/eigen-5.0.0`。
- **未改任何 `src/` 代码、未改 CMake/CHANGELOG/版本号、未提交 git**；`v34_sweep*.exe` 只是把产品源码
  编译进独立分析工具，不进入任何构建树。结论已记入 `Document/ChangingLog/完整更新日志.md`。
